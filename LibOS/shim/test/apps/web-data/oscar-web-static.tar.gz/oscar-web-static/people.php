

<html>

<head>
    <title>People | Operating System Security Concurrency and Architecture Research Lab</title>

    <link rel="StyleSheet" href="style.css" type="text/css">
    <link rel='Shortcut Icon' href="images/oscar-favicon.png" type="image/png">

</head>

<body>
    <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-26854735-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
    <div class="wrapper">
        <div class="wrapper navigation">
           <div class="univ" style="background-image: url(images/sbu-logo-small.gif)">
               <a href="http://www.stonybrook.edu/" target="_blank">
                    <span>Stony Brook University</span>
               </a>
            </div>
            <div class="dept" style="background-image: url(images/cs-logo-small.gif)">
                <a href="http://www.cs.stonybrook.edu/" target="_blank">
                    <span>Computer Science Department</span>
                </a>
            </div>
        </div>

        <div class="wrapper">
            <div class="header" style="background-image: url(images/banner.jpg)">
            <a href="index.php">
                <div class="title">
                    <span class="l1"><b>O</b>perating System <b>S</b>ecurity <b>C</b>oncurrency<br/></span>
                    <span class="l2">and <b>A</b>rchitecture <b>R</b>esearch Lab</span>
                </div>
            </a>
            </div>
        </div>
    </div>

    <div class="content_wrapper">
        <div class="wrapper">

            <div class="gears">
                <div class="gear1" style="background-image: url(images/gear1.png)">
                    <p><a href="people.php">People</a></p>
                </div>

                <div class="gear2" style="background-image: url(images/gear2.png)">
                    <p><a href="news.php">News</a></p>
                </div>
                <div class="gear3" style="background-image: url(images/gear2.png)">
                    <p><a href="projects.php">Projects</a></p>
                </div>
                <div class="gear2" style="background-image: url(images/gear2.png)">
                    <p><a href="papers.php">Papers</a></p>
                </div>
                <div class="gear3" style="background-image: url(images/gear2.png)">
                    <p><a href="sponsors.php">Sponsors</a></p>
                </div>
            </div>

            <div class="content">
<!-- include_once /root/oscar-web/people/mani.php -->
<!-- content add Array
(
    [name] => Manikantan Subramanian
    [title] => Master's Student, Fall 2011, Computer Science, Stony Brook University
    [office] => 2203 Computer Science
    [email] => masubramania@cs.stonybrook.edu
    [website] => 
    [phone] => 6316821834
    [fax] => 
    [photo] => people/photos/mani.png
)
 -->

<!-- include_once /root/oscar-web/people/xuan.php -->
<!-- content add Array
(
    [name] => Xuan Wang
    [title] => Masters Student, Computer Science, Stony Brook University
    [office] => 2203 Computer Science
    [email] => wang9@cs.stonybrook.edu
    [website] => http://www.cs.stonybrook.edu/~wang9/
    [phone] => 
    [fax] => 
    [photo] => people/photos/xuan.jpg
    [alumnus] => 1
)
 -->

<!-- include_once /root/oscar-web/people/ankur.php -->
<!-- content add Array
(
    [name] => Ankur Agrawal
    [title] => Master's Student, Computer Science, Stony Brook University
    [office] => 2203 Computer Science
    [email] => anagrawal@cs.stonybrook.edu
    [website] => 
    [phone] => 
    [fax] => 
    [photo] => people/photos/ankur.jpg
)
 -->

<!-- include_once /root/oscar-web/people/nehal.php -->
<!-- content add Array
(
    [name] => Nehal Bandi
    [title] => Masters Student, Computer Science, Stony Brook University
    [office] => 2203 Computer Science
    [email] => nbandi@cs.stonybrook.edu
    [website] => 
    [phone] => 
    [fax] => 
    [photo] => people/photos/nehal.jpg
)
 -->

<!-- include_once /root/oscar-web/people/gurpreet.php -->
<!-- content add Array
(
    [name] => Gurpreet Chadha
    [title] => Masters Student, Computer Science, Stony Brook University
    [office] => 2203 Computer Science
    [email] => gchadha@cs.cs.stonybrook.edu
    [website] => 
    [phone] => 
    [fax] => 
    [photo] => people/photos/gurpreet.jpg
    [alumnus] => 1
)
 -->

<!-- include_once /root/oscar-web/people/porter.php -->
<!-- content add Array
(
    [name] => Donald Porter
    [title] => Assistant Professor, Computer Science, Stony Brook University
    [office] => 1434 Computer Science
    [email] => porter@cs.stonybrook.edu
    [website] => http://www.cs.sunysb.edu/~porter/
    [phone] => 
    [fax] => 
    [photo] => people/photos/porter.png
)
 -->

<!-- include_once /root/oscar-web/people/example.php --><!-- include_once /root/oscar-web/people/naveen.php -->
<!-- content add Array
(
    [name] => Naveen Kumar Kalaskar
    [title] => Masters Student, Fall 2011
    [office] => 2203, OSCAR LAB, Computer Science
    [email] => nkalaskar@cs.stonybrook.edu, naveen.kalaskar@gmail.com
    [website] => 
    [phone] => 571 423 9479
    [fax] => 
    [photo] => people/photos/naveen.jpg
)
 -->

<!-- include_once /root/oscar-web/people/chiache.php -->
<!-- content add Array
(
    [name] => Chia-Che Tsai
    [title] => Doctoral Student, Computer Science, Stony Brook University
    [office] => 2203 Computer Science
    [email] => chitsai@cs.stonybrook.edu
    [website] => http://www.cs.stonybrook.edu/~chitsai
    [phone] => 
    [fax] => 
    [photo] => people/photos/chiache.jpg
)
 -->

<!-- include_once /root/oscar-web/people/william.php -->
<!-- content add Array
(
    [name] => William Jannen
    [title] => Doctoral Student, Computer Science, Stony Brook University
    [office] => 2203 Computer Science
    [email] => wjannen@cs.stonybrook.edu
    [website] => http://www.cs.stonybrook.edu/~wjannen/
    [phone] => 
    [fax] => 
    [photo] => people/photos/WilliamJannen.jpg
)
 -->

<!-- include_once /root/oscar-web/people/ujwala.php -->
<!-- content add Array
(
    [name] => Ujwala Tulshigiri
    [title] => Graduate Student, Computer Science, Stony Brook University
    [office] => 2203 Computer Science
    [email] => utulshigiri@cs.stonybrook.edu
    [website] => 
    [phone] => 
    [fax] => 
    [photo] => people/photos/ujwala.jpg
)
 -->

    <h1>
        People
            </h1>


    <h6>It is our pleasure to work with numbers of extraordinary researchers.</h6>



<div class="content_list">
    <table class="people">

<tr>
    <td class="photo">
        <img src="people/photos/porter.png">
    </td>
    <td class="info">
                    <h3>Donald Porter</h3>
        
                    <h5>Assistant Professor, Computer Science, Stony Brook University</h5>
        
        <ul style="list-style-type: none; padding: 0">
                          <li>Office: 1434 Computer Science</li> 
           
                          <li>Email:
                   <script type="text/javascript">
        <!--
            var string1 = "porter";
            var string2 = "@";
            var string3 = "cs.stonybrook.edu";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
               </li>
           
                          <li>Website:
                              <a href="http://www.cs.sunysb.edu/~porter/" target="_blank">
                       http://www.cs.sunysb.edu/~porter/                   </a>
                          </li>
           
           
                   </ul>

            </td>
</tr>
<tr>
    <td class="photo">
        <img src="people/photos/ankur.jpg">
    </td>
    <td class="info">
                    <h3>Ankur Agrawal</h3>
        
                    <h5>Master's Student, Computer Science, Stony Brook University</h5>
        
        <ul style="list-style-type: none; padding: 0">
                          <li>Office: 2203 Computer Science</li> 
           
                          <li>Email:
                   <script type="text/javascript">
        <!--
            var string1 = "anagrawal";
            var string2 = "@";
            var string3 = "cs.stonybrook.edu";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
               </li>
           
           
           
                   </ul>

            </td>
</tr>
<tr>
    <td class="photo">
        <img src="people/photos/nehal.jpg">
    </td>
    <td class="info">
                    <h3>Nehal Bandi</h3>
        
                    <h5>Masters Student, Computer Science, Stony Brook University</h5>
        
        <ul style="list-style-type: none; padding: 0">
                          <li>Office: 2203 Computer Science</li> 
           
                          <li>Email:
                   <script type="text/javascript">
        <!--
            var string1 = "nbandi";
            var string2 = "@";
            var string3 = "cs.stonybrook.edu";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
               </li>
           
           
           
                   </ul>

                       <a href="people.php?page=nehal">
                   More About Me
               </a>
            </td>
</tr>
<tr>
    <td class="photo">
        <img src="people/photos/WilliamJannen.jpg">
    </td>
    <td class="info">
                    <h3>William Jannen</h3>
        
                    <h5>Doctoral Student, Computer Science, Stony Brook University</h5>
        
        <ul style="list-style-type: none; padding: 0">
                          <li>Office: 2203 Computer Science</li> 
           
                          <li>Email:
                   <script type="text/javascript">
        <!--
            var string1 = "wjannen";
            var string2 = "@";
            var string3 = "cs.stonybrook.edu";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
               </li>
           
                          <li>Website:
                              <a href="http://www.cs.stonybrook.edu/~wjannen/" target="_blank">
                       http://www.cs.stonybrook.edu/~wjannen/                   </a>
                          </li>
           
           
                   </ul>

            </td>
</tr>
<tr>
    <td class="photo">
        <img src="people/photos/naveen.jpg">
    </td>
    <td class="info">
                    <h3>Naveen Kumar Kalaskar</h3>
        
                    <h5>Masters Student, Fall 2011</h5>
        
        <ul style="list-style-type: none; padding: 0">
                          <li>Office: 2203, OSCAR LAB, Computer Science</li> 
           
                          <li>Email:
                   <script type="text/javascript">
        <!--
            var string1 = "nkalaskar";
            var string2 = "@";
            var string3 = "cs.stonybrook.edu";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
        <script type="text/javascript">
        <!--
            var string1 = "naveen.kalaskar";
            var string2 = "@";
            var string3 = "gmail.com";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
               </li>
           
           
                          <li>Phone: 571 423 9479</li> 
           
                   </ul>

                       <a href="people.php?page=naveen">
                   More About Me
               </a>
            </td>
</tr>
<tr>
    <td class="photo">
        <img src="people/photos/mani.png">
    </td>
    <td class="info">
                    <h3>Manikantan Subramanian</h3>
        
                    <h5>Master's Student, Fall 2011, Computer Science, Stony Brook University</h5>
        
        <ul style="list-style-type: none; padding: 0">
                          <li>Office: 2203 Computer Science</li> 
           
                          <li>Email:
                   <script type="text/javascript">
        <!--
            var string1 = "masubramania";
            var string2 = "@";
            var string3 = "cs.stonybrook.edu";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
               </li>
           
           
                          <li>Phone: 6316821834</li> 
           
                   </ul>

            </td>
</tr>
<tr>
    <td class="photo">
        <img src="people/photos/chiache.jpg">
    </td>
    <td class="info">
                    <h3>Chia-Che Tsai</h3>
        
                    <h5>Doctoral Student, Computer Science, Stony Brook University</h5>
        
        <ul style="list-style-type: none; padding: 0">
                          <li>Office: 2203 Computer Science</li> 
           
                          <li>Email:
                   <script type="text/javascript">
        <!--
            var string1 = "chitsai";
            var string2 = "@";
            var string3 = "cs.stonybrook.edu";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
               </li>
           
                          <li>Website:
                              <a href="http://www.cs.stonybrook.edu/~chitsai" target="_blank">
                       http://www.cs.stonybrook.edu/~chitsai                   </a>
                          </li>
           
           
                   </ul>

                       <a href="people.php?page=chiache">
                   More About Me
               </a>
            </td>
</tr>
<tr>
    <td class="photo">
        <img src="people/photos/ujwala.jpg">
    </td>
    <td class="info">
                    <h3>Ujwala Tulshigiri</h3>
        
                    <h5>Graduate Student, Computer Science, Stony Brook University</h5>
        
        <ul style="list-style-type: none; padding: 0">
                          <li>Office: 2203 Computer Science</li> 
           
                          <li>Email:
                   <script type="text/javascript">
        <!--
            var string1 = "utulshigiri";
            var string2 = "@";
            var string3 = "cs.stonybrook.edu";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
               </li>
           
           
           
                   </ul>

                       <a href="people.php?page=ujwala">
                   More About Me
               </a>
            </td>
</tr>
    </table>
</div>
      <br/>
      <h2>Alumni</h2>

<div class="content_list">
    <table class="people">

<tr>
    <td class="photo">
        <img src="people/photos/gurpreet.jpg">
    </td>
    <td class="info">
                    <h3>Gurpreet Chadha</h3>
        
                    <h5>Masters Student, Computer Science, Stony Brook University</h5>
        
        <ul style="list-style-type: none; padding: 0">
                          <li>Office: 2203 Computer Science</li> 
           
                          <li>Email:
                   <script type="text/javascript">
        <!--
            var string1 = "gchadha";
            var string2 = "@";
            var string3 = "cs.cs.stonybrook.edu";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
               </li>
           
           
           
                   </ul>

            </td>
</tr>
<tr>
    <td class="photo">
        <img src="people/photos/xuan.jpg">
    </td>
    <td class="info">
                    <h3>Xuan Wang</h3>
        
                    <h5>Masters Student, Computer Science, Stony Brook University</h5>
        
        <ul style="list-style-type: none; padding: 0">
                          <li>Office: 2203 Computer Science</li> 
           
                          <li>Email:
                   <script type="text/javascript">
        <!--
            var string1 = "wang9";
            var string2 = "@";
            var string3 = "cs.stonybrook.edu";
            var string4 = string1 + string2 + string3;
            document.write("<a href=" + "mail" + "to:" + 
                           string1 + string2 + string3 + ">" + 
                           string4 + "</a>");
        //-->
        </script>
               </li>
           
                          <li>Website:
                              <a href="http://www.cs.stonybrook.edu/~wang9/" target="_blank">
                       http://www.cs.stonybrook.edu/~wang9/                   </a>
                          </li>
           
           
                   </ul>

            </td>
</tr>
    </table>
</div>
            </div>
        </div>
    </div>

    <div class="wrapper">
    </div>

    <div class="wrapper">
        <div class="labcontact">OSCAR Lab, Room 2203, Computer Science Building, Stony Brook University, Stony Brook, NY 11794-4400</div>
    </div>
</body>
</html>

