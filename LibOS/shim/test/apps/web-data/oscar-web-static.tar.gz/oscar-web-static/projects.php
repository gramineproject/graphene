

<html>

<head>
    <title>Projects | Operating System Security Concurrency and Architecture Research Lab</title>

    <link rel="StyleSheet" href="style.css" type="text/css">
    <link rel='Shortcut Icon' href="images/oscar-favicon.png" type="image/png">

</head>

<body>
    <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-26854735-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
    <div class="wrapper">
        <div class="wrapper navigation">
           <div class="univ" style="background-image: url(images/sbu-logo-small.gif)">
               <a href="http://www.stonybrook.edu/" target="_blank">
                    <span>Stony Brook University</span>
               </a>
            </div>
            <div class="dept" style="background-image: url(images/cs-logo-small.gif)">
                <a href="http://www.cs.stonybrook.edu/" target="_blank">
                    <span>Computer Science Department</span>
                </a>
            </div>
        </div>

        <div class="wrapper">
            <div class="header" style="background-image: url(images/banner.jpg)">
            <a href="index.php">
                <div class="title">
                    <span class="l1"><b>O</b>perating System <b>S</b>ecurity <b>C</b>oncurrency<br/></span>
                    <span class="l2">and <b>A</b>rchitecture <b>R</b>esearch Lab</span>
                </div>
            </a>
            </div>
        </div>
    </div>

    <div class="content_wrapper">
        <div class="wrapper">

            <div class="gears">
                <div class="gear1" style="background-image: url(images/gear1.png)">
                    <p><a href="projects.php">Projects</a></p>
                </div>

                <div class="gear2" style="background-image: url(images/gear2.png)">
                    <p><a href="news.php">News</a></p>
                </div>
                <div class="gear3" style="background-image: url(images/gear2.png)">
                    <p><a href="people.php">People</a></p>
                </div>
                <div class="gear2" style="background-image: url(images/gear2.png)">
                    <p><a href="papers.php">Papers</a></p>
                </div>
                <div class="gear3" style="background-image: url(images/gear2.png)">
                    <p><a href="sponsors.php">Sponsors</a></p>
                </div>
            </div>

            <div class="content">
<!-- include_once /root/oscar-web/projects/virtualization.php -->
<!-- content add Array
(
    [title] => Operating System Virtualization
    [area] => Systems, Security
    [prerequisite] => C/C++/Assembly Programming, UNIX & Kernel Knowledge
    [description] => Virtualization in operating systems is a technique to build virtual layers upon host systems to accommadate isolated systems. We are investigating novel virtualization techniques and applications of virtualization to improve the efficiency and utility of virtual machines.
)
 -->

<!-- include_once /root/oscar-web/projects/example.php --><!-- include_once /root/oscar-web/projects/transactions.php -->
<!-- content add Array
(
    [title] => Operating System Transactions
    [area] => Systems, Programming, Concurrency
    [prerequisite] => Experience with multi-threaded programming.  Formal methods experience a big plus.
    [description] => We are exploring techniques to make multi-core computers easier to program, both in the OS and in applications.  Our work focuses on improved data structure and library designs that encapsulate this complexity from the programmer.
)
 -->

<!-- include_once /root/oscar-web/projects/concurrency.php -->
<!-- content add Array
(
    [title] => Concurrent Programming
    [area] => Systems, Programming, Concurrency
    [prerequisite] => C Programming, UNIX & Kernel Knowledge.  Experience with multi-threaded programming or transactional memory a big plus.
    [description] => We are exploring novel techniques for implementing transactions in Linux, as well as new uses of transactions to make system-level programming easier for users.
)
 -->


    <h1>
        Projects
            </h1>

    <h6>We are looking for outstanding, enthusiastic students 
    to join our lab.  Several ongoing projects are listed below.
    If you are interested in joining the lab, the best way to 
    begin is to take a systems course with Professor Porter or 
    otherwise get to know the lab members.
    </h6>

    <h6>If you are considering applying to Stony Brook, 
    we encourage you to apply to the department.  Please note
    that you must be admitted to the department before you can join 
    our lab, and that we cannot pre-admit any students.
    </h6>



<div class="content_list">
    <div class="projects">
                    <div class="title">Operating System Transactions</div> 
        
                    <div class="area">Related Areas: Systems, Programming, Concurrency</div> 
        
                    <div class="prereq">Prerequisite: Experience with multi-threaded programming.  Formal methods experience a big plus.</div>
        
                    <div class="desc">We are exploring techniques to make multi-core computers easier to program, both in the OS and in applications.  Our work focuses on improved data structure and library designs that encapsulate this complexity from the programmer.</div>
        
            </div>
    <div class="projects">
                    <div class="title">Operating System Virtualization</div> 
        
                    <div class="area">Related Areas: Systems, Security</div> 
        
                    <div class="prereq">Prerequisite: C/C++/Assembly Programming, UNIX & Kernel Knowledge</div>
        
                    <div class="desc">Virtualization in operating systems is a technique to build virtual layers upon host systems to accommadate isolated systems. We are investigating novel virtualization techniques and applications of virtualization to improve the efficiency and utility of virtual machines.</div>
        
            </div>
    <div class="projects">
                    <div class="title">Concurrent Programming</div> 
        
                    <div class="area">Related Areas: Systems, Programming, Concurrency</div> 
        
                    <div class="prereq">Prerequisite: C Programming, UNIX & Kernel Knowledge.  Experience with multi-threaded programming or transactional memory a big plus.</div>
        
                    <div class="desc">We are exploring novel techniques for implementing transactions in Linux, as well as new uses of transactions to make system-level programming easier for users.</div>
        
            </div>
</div>

            </div>
        </div>
    </div>

    <div class="wrapper">
    </div>

    <div class="wrapper">
        <div class="labcontact">OSCAR Lab, Room 2203, Computer Science Building, Stony Brook University, Stony Brook, NY 11794-4400</div>
    </div>
</body>
</html>

