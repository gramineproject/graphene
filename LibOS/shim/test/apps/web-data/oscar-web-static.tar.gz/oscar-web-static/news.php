

<html>

<head>
    <title>News | Operating System Security Concurrency and Architecture Research Lab</title>

    <link rel="StyleSheet" href="style.css" type="text/css">
    <link rel='Shortcut Icon' href="images/oscar-favicon.png" type="image/png">

</head>

<body>
    <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-26854735-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
    <div class="wrapper">
        <div class="wrapper navigation">
           <div class="univ" style="background-image: url(images/sbu-logo-small.gif)">
               <a href="http://www.stonybrook.edu/" target="_blank">
                    <span>Stony Brook University</span>
               </a>
            </div>
            <div class="dept" style="background-image: url(images/cs-logo-small.gif)">
                <a href="http://www.cs.stonybrook.edu/" target="_blank">
                    <span>Computer Science Department</span>
                </a>
            </div>
        </div>

        <div class="wrapper">
            <div class="header" style="background-image: url(images/banner.jpg)">
            <a href="index.php">
                <div class="title">
                    <span class="l1"><b>O</b>perating System <b>S</b>ecurity <b>C</b>oncurrency<br/></span>
                    <span class="l2">and <b>A</b>rchitecture <b>R</b>esearch Lab</span>
                </div>
            </a>
            </div>
        </div>
    </div>

    <div class="content_wrapper">
        <div class="wrapper">

            <div class="gears">
                <div class="gear1" style="background-image: url(images/gear1.png)">
                    <p><a href="news.php">News</a></p>
                </div>

                <div class="gear2" style="background-image: url(images/gear2.png)">
                    <p><a href="people.php">People</a></p>
                </div>
                <div class="gear3" style="background-image: url(images/gear2.png)">
                    <p><a href="projects.php">Projects</a></p>
                </div>
                <div class="gear2" style="background-image: url(images/gear2.png)">
                    <p><a href="papers.php">Papers</a></p>
                </div>
                <div class="gear3" style="background-image: url(images/gear2.png)">
                    <p><a href="sponsors.php">Sponsors</a></p>
                </div>
            </div>

            <div class="content">
<!-- include_once /root/oscar-web/news/cewit2011.php -->
<!-- content add Array
(
    [date] => 10/21/2011
    [title] => Three Posters accepted in CEWIT Conference 2011
    [description] => CEWIT 2011 - The 8th International Conference & Expo on Emerging Technologies 
for a Smarter World. <br/><a href="http://www.cewit.org/conference2011">http://www.cewit.org/conference2011</a>
)
 -->

<!-- include_once /root/oscar-web/news/example.php --><!-- include_once /root/oscar-web/news/grc12.php -->
<!-- content add Array
(
    [date] => 3/30/12
    [title] => OSCAR wins the GRC Lab Cup
    [description] => At the <a href="http://www.cs.stonybrook.edu/~grc/">2012 Stony Brook CS Graduate Research Conference (GRC Day)</a>, OSCAR lab won the lab cup.  Don Porter also won the Most Supportive Professor Award.
)
 -->

<!-- include_once /root/oscar-web/news/career.php -->
<!-- content add Array
(
    [date] => 12/22/11
    [title] => Professor Porter awarded NSF CAREER grant
    [description] => <a href="http://www.nsf.gov/awardsearch/showAward.do?AwardNumber=1149229">CAREER: Beyond Virtual Hardware: VMM/OS Co-Design for Lightweight, Flexible Virtualization.</a><br/>

Read the university press release <a href="http://www.cs.stonybrook.edu/about/news/donPorterNSF2012.html">here.</a><br/>

This award also generated <a href="http://www.northshoreoflongisland.com/Articles-Arts-and-Lifestyles-i-2012-04-19-92067.112114-SBU-professors-goal-to-demystify-the-computer.html">a nice story</a> about the lab in the local newspaper.

)
 -->

<!-- include_once /root/oscar-web/news/texos.php -->
<!-- content add Array
(
    [date] => 1/10/12
    [title] => TxOS Paper accepted to EuroSys 2012
    [description] => <b>Improving Server Applications with System Transactions</b><br>
<a href="http://www.cs.utexas.edu/~sangmank/">Sangman Kim</a>,
<a href="http://www.cs.utexas.edu/~mzlee/">Michael Z. Lee</a>,
<a href="http://www.cs.utexas.edu/~adunn/">Alan M. Dunn</a>,
<a href="http://www.cs.utexas.edu/~osh/">Owen S. Hofmann</a>, 
<a href="http://www.cs.stonybrook.edu/~wang9/"> Xuan Wang</a>,
<a href="http://www.cs.utexas.edu/users/witchel/">Emmett Witchel</a>,
<a href="http://www.cs.stonybrook.edu/~porter/"> and Donald E. Porter</a>
<br>
(<a
 href="http://www.cs.stonybrook.edu/~porter/pubs/kim12eurosys-txos+.pdf">PDF</a>)
<br>

In the <i>Proceedings of the 7th ACM European Conference on Computer Systems
(<a href="http://eurosys2012.unibe.ch/">EuroSys '12</a>)</i>, Bern, Switzerland, April 2012. <br/>
)
 -->


    <h6><b>OSCAR Lab</b> was founded in spring 2011 in Computer Science department, 
    Stony Brook University. We are working on research related issues in the areas 
    of Operating Systems, Virtualization, System Security, Concurrency and Computer 
    Architecture.</h6>

    <h3> News
            </h3>

<div class="content_list">
    <div class="news">
                    <div class="title">OSCAR wins the GRC Lab Cup</div> 
        
                    <div class="date">Posted: 3/30/12</div> 
        
                    <div class="desc">At the <a href="http://www.cs.stonybrook.edu/~grc/">2012 Stony Brook CS Graduate Research Conference (GRC Day)</a>, OSCAR lab won the lab cup.  Don Porter also won the Most Supportive Professor Award.</div>
        
            </div>
    <div class="news">
                    <div class="title">TxOS Paper accepted to EuroSys 2012</div> 
        
                    <div class="date">Posted: 1/10/12</div> 
        
                    <div class="desc"><b>Improving Server Applications with System Transactions</b><br>
<a href="http://www.cs.utexas.edu/~sangmank/">Sangman Kim</a>,
<a href="http://www.cs.utexas.edu/~mzlee/">Michael Z. Lee</a>,
<a href="http://www.cs.utexas.edu/~adunn/">Alan M. Dunn</a>,
<a href="http://www.cs.utexas.edu/~osh/">Owen S. Hofmann</a>, 
<a href="http://www.cs.stonybrook.edu/~wang9/"> Xuan Wang</a>,
<a href="http://www.cs.utexas.edu/users/witchel/">Emmett Witchel</a>,
<a href="http://www.cs.stonybrook.edu/~porter/"> and Donald E. Porter</a>
<br>
(<a
 href="http://www.cs.stonybrook.edu/~porter/pubs/kim12eurosys-txos+.pdf">PDF</a>)
<br>

In the <i>Proceedings of the 7th ACM European Conference on Computer Systems
(<a href="http://eurosys2012.unibe.ch/">EuroSys '12</a>)</i>, Bern, Switzerland, April 2012. <br/></div>
        
            </div>
    <div class="news">
                    <div class="title">Professor Porter awarded NSF CAREER grant</div> 
        
                    <div class="date">Posted: 12/22/11</div> 
        
                    <div class="desc"><a href="http://www.nsf.gov/awardsearch/showAward.do?AwardNumber=1149229">CAREER: Beyond Virtual Hardware: VMM/OS Co-Design for Lightweight, Flexible Virtualization.</a><br/>

Read the university press release <a href="http://www.cs.stonybrook.edu/about/news/donPorterNSF2012.html">here.</a><br/>

This award also generated <a href="http://www.northshoreoflongisland.com/Articles-Arts-and-Lifestyles-i-2012-04-19-92067.112114-SBU-professors-goal-to-demystify-the-computer.html">a nice story</a> about the lab in the local newspaper.
</div>
        
            </div>
    <div class="news">
                    <div class="title">Three Posters accepted in CEWIT Conference 2011</div> 
        
                    <div class="date">Posted: 10/21/2011</div> 
        
                    <div class="desc">CEWIT 2011 - The 8th International Conference & Expo on Emerging Technologies 
for a Smarter World. <br/><a href="http://www.cewit.org/conference2011">http://www.cewit.org/conference2011</a></div>
        
            </div>
</div>

            </div>
        </div>
    </div>

    <div class="wrapper">
    </div>

    <div class="wrapper">
        <div class="labcontact">OSCAR Lab, Room 2203, Computer Science Building, Stony Brook University, Stony Brook, NY 11794-4400</div>
    </div>
</body>
</html>

