

<html>

<head>
    <title>Papers | Operating System Security Concurrency and Architecture Research Lab</title>

    <link rel="StyleSheet" href="style.css" type="text/css">
    <link rel='Shortcut Icon' href="images/oscar-favicon.png" type="image/png">

</head>

<body>
    <script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-26854735-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
    <div class="wrapper">
        <div class="wrapper navigation">
           <div class="univ" style="background-image: url(images/sbu-logo-small.gif)">
               <a href="http://www.stonybrook.edu/" target="_blank">
                    <span>Stony Brook University</span>
               </a>
            </div>
            <div class="dept" style="background-image: url(images/cs-logo-small.gif)">
                <a href="http://www.cs.stonybrook.edu/" target="_blank">
                    <span>Computer Science Department</span>
                </a>
            </div>
        </div>

        <div class="wrapper">
            <div class="header" style="background-image: url(images/banner.jpg)">
            <a href="index.php">
                <div class="title">
                    <span class="l1"><b>O</b>perating System <b>S</b>ecurity <b>C</b>oncurrency<br/></span>
                    <span class="l2">and <b>A</b>rchitecture <b>R</b>esearch Lab</span>
                </div>
            </a>
            </div>
        </div>
    </div>

    <div class="content_wrapper">
        <div class="wrapper">

            <div class="gears">
                <div class="gear1" style="background-image: url(images/gear1.png)">
                    <p><a href="papers.php">Papers</a></p>
                </div>

                <div class="gear2" style="background-image: url(images/gear2.png)">
                    <p><a href="news.php">News</a></p>
                </div>
                <div class="gear3" style="background-image: url(images/gear2.png)">
                    <p><a href="people.php">People</a></p>
                </div>
                <div class="gear2" style="background-image: url(images/gear2.png)">
                    <p><a href="projects.php">Projects</a></p>
                </div>
                <div class="gear3" style="background-image: url(images/gear2.png)">
                    <p><a href="sponsors.php">Sponsors</a></p>
                </div>
            </div>

            <div class="content">
<!-- include_once /root/oscar-web/papers/example.php --><!-- include_once /root/oscar-web/papers/texos12.php -->
<!-- content add Array
(
    [title] => Improving Server Applications with System Transactions
    [publish] => EuroSys 2012
    [publish_link] => http://eurosys2012.unibe.ch/
    [biblio] => 
Improving Server Applications with System Transactions Sangman Kim,
Michael Z. Lee, Alan M. Dunn, Owen S. Hofmann, Xuan Wang, Emmett Witchel,
and Donald E. Porter, In the Proceedings of the 7th ACM European Conference
on Computer Systems (EuroSys '12), Bern, Switzerland, April 2012
    [format] => Array
        (
            [pdf] => http://www.cs.stonybrook.edu/~porter/pubs/kim12eurosys-txos+.pdf
        )

)
 -->


    <h1> Paper Published
            </h1>

<div class="content_list">
    <div class="papers">
                    <div class="title">Improving Server Applications with System Transactions</div> 
        
                    <div class="publish"> published on
                            <a href="http://eurosys2012.unibe.ch/">
                EuroSys 2012                </a>
                        </div>
        
                    <div class="biblio">
Improving Server Applications with System Transactions Sangman Kim,
Michael Z. Lee, Alan M. Dunn, Owen S. Hofmann, Xuan Wang, Emmett Witchel,
and Donald E. Porter, In the Proceedings of the 7th ACM European Conference
on Computer Systems (EuroSys '12), Bern, Switzerland, April 2012</div>
        
                    <div class="format">
                            <a href="http://www.cs.stonybrook.edu/~porter/pubs/kim12eurosys-txos+.pdf">[pdf]</a>
                        </div>
        

            </div>
</div>

            </div>
        </div>
    </div>

    <div class="wrapper">
    </div>

    <div class="wrapper">
        <div class="labcontact">OSCAR Lab, Room 2203, Computer Science Building, Stony Brook University, Stony Brook, NY 11794-4400</div>
    </div>
</body>
</html>

