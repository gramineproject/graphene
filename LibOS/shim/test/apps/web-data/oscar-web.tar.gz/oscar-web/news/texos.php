<?php

## Fill in the information
#

$new = array(
    "date"        => "1/10/12",
    "title"       => "TxOS Paper accepted to EuroSys 2012",
    "description" => "<b>Improving Server Applications with System Transactions</b><br>
<a href=\"http://www.cs.utexas.edu/~sangmank/\">Sangman Kim</a>,
<a href=\"http://www.cs.utexas.edu/~mzlee/\">Michael Z. Lee</a>,
<a href=\"http://www.cs.utexas.edu/~adunn/\">Alan M. Dunn</a>,
<a href=\"http://www.cs.utexas.edu/~osh/\">Owen S. Hofmann</a>, 
<a href=\"http://www.cs.stonybrook.edu/~wang9/\"> Xuan Wang</a>,
<a href=\"http://www.cs.utexas.edu/users/witchel/\">Emmett Witchel</a>,
<a href=\"http://www.cs.stonybrook.edu/~porter/\"> and Donald E. Porter</a>
<br>
(<a
 href=\"http://www.cs.stonybrook.edu/~porter/pubs/kim12eurosys-txos+.pdf\">PDF</a>)
<br>

In the <i>Proceedings of the 7th ACM European Conference on Computer Systems
(<a href=\"http://eurosys2012.unibe.ch/\">EuroSys '12</a>)</i>, Bern, Switzerland, April 2012. <br/>",
);

## The following content will be shown in a individual page.
#
# if (Content::InContentPage()) {
# }

## Add it to the content.
#
Content::Add($new, "20120110");

?>
