<?php
# attribute.php
#
# Author: Chia-che Tsai
# Created: 09/08/2011
# Updated: 09/08/2011

if (!defined('IN_SERVER')) {
    exit('Access Denied');
}

define('SERVER_NAME', 
'Operating System Security Concurrency and Architecture Research Lab');

define('CONTACT', 
'OSCAR Lab, Room 2203, Computer Science Building, Stony Brook University, Stony Brook, NY 11794-4400');

?>
