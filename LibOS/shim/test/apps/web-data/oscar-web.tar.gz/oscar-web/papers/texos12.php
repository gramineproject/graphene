<?php

## Fill in the information
#

$texos12 = array(
    "title"        => "Improving Server Applications with System Transactions",
    "publish"      => "EuroSys 2012",
    "publish_link" => "http://eurosys2012.unibe.ch/",
    "biblio"       => "
Improving Server Applications with System Transactions Sangman Kim,
Michael Z. Lee, Alan M. Dunn, Owen S. Hofmann, Xuan Wang, Emmett Witchel,
and Donald E. Porter, In the Proceedings of the 7th ACM European Conference
on Computer Systems (EuroSys '12), Bern, Switzerland, April 2012",
    "format"       => array("pdf" =>
            "http://www.cs.stonybrook.edu/~porter/pubs/kim12eurosys-txos+.pdf")
);

## The following content will be shown in a individual page.
#
# if (Content::InContentPage()) {
# }

## Add it to the content.
#
Content::Add($texos12, '20120110');

?>
