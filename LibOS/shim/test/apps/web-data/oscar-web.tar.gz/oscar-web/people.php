<?php
# people.php
#
# Author: Chia-che Tsai
# Created: 09/12/2011
# Updated: 09/12/2011


define('PAGE_TITLE', 'People');

define('SERVER_ROOT', dirname($_SERVER['SCRIPT_FILENAME']) . '/');
define('IN_SERVER', true);

include_once SERVER_ROOT . 'attribute.php';
include_once SERVER_ROOT . 'common.php';

define('PAGE_NAME', 'People');
define('PAGE_FILENAME', 'people.php');
define('CONTENT_TYPE', 'people');

include_once SERVER_ROOT . 'common.main.php';
include_once SERVER_ROOT . 'header.main.php';
?>
    <h1>
        People
        <? if (defined('CONTENT_PAGE')) {
               $items = Content::Items();
               echo '> ' . $items[0]['name'];
           } ?>
    </h1>


<? if (!defined('CONTENT_PAGE')) { ?>
    <h6>It is our pleasure to work with numbers of extraordinary researchers.</h6>
<? } ?>


<?
if (!defined('CONTENT_PAGE'))
    $iter_alumni = array(False, True);
else
    $iter_alumni = array(False);

foreach ($iter_alumni as $alumni) {
    if ($alumni) { ?>
      <br/>
      <h2>Alumni</h2>
<?  } ?>

<div class="content_list">
    <table class="people">

<?  foreach (Content::Items() as $item) {
        if (!defined('CONTENT_PAGE'))
            if ($alumni xor $item['alumnus'])
                continue;
?>
<tr>
    <td class="photo">
        <img src="<?
        if (strpos($item['photo'], "http:") === 0) {
            echo $item['photo'];
        } else {
            echo URL_ROOT . $item['photo'];
        }
        ?>">
    </td>
    <td class="info">
        <? if ($item['name']) { ?>
            <h3><? echo $item['name'] ?></h3>
        <? } ?>

        <? if ($item['title']) { ?>
            <h5><? echo $item['title'] ?></h5>
        <? } ?>

        <ul style="list-style-type: none; padding: 0">
           <? if ($item['office']) { ?>
               <li>Office: <? echo $item['office'] ?></li> 
           <? } ?>

           <? if ($item['email']) { ?>
               <li>Email:
           <?     $emails = array_map('trim', explode(',', $item['email']));
                  foreach ($emails as $email) {
                      hide_email_address($email);
                  } ?>
               </li>
           <?   } ?>

           <? if ($item['website']) { ?>
               <li>Website:
           <?     $websites = array_map('trim', explode(',', $item['website']));
                  foreach ($websites as $website) { ?>
                   <a href="<? echo $website ?>" target="_blank">
                       <? echo $website ?>
                   </a>
           <?     } ?>
               </li>
           <? } ?>

           <? if ($item['phone']) { ?>
               <li>Phone: <? echo $item['phone'] ?></li> 
           <? } ?>

           <? if ($item['fax']) { ?>
               <li>Fax: <? echo $item['fax'] ?></li> 
           <? } ?>
        </ul>

        <? if (!defined('CONTENT_PAGE') && $item['page']) { ?>
               <a href="<? echo URL_ROOT . PAGE_FILENAME . '?page=' . $item['page']?>">
                   More About Me
               </a>
        <? } ?>
    </td>
</tr>
<?  } ?>
    </table>
</div>
<?
}

include_once SERVER_ROOT . 'footer.main.php';
?>
