<?php 
# footer.php
#
# Author: Chia-che Tsai
# Created: 09/08/2011
# Updated: 09/09/2011

if (!defined('IN_SERVER')) {
    exit('Access Denied');
}
?>
    </div>

    <div class="wrapper">
        <div class="labcontact"><? echo CONTACT ?></div>
    </div>
</body>
</html>

