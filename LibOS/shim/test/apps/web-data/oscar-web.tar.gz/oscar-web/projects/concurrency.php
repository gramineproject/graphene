<?php

$conc = array(
    "title"        => "Concurrent Programming",
    "area"         => "Systems, Programming, Concurrency",
    "prerequisite" => "C Programming, UNIX & Kernel Knowledge.  Experience with multi-threaded programming or transactional memory a big plus.",
    "description"  => "We are exploring novel techniques for implementing transactions in Linux, as well as new uses of transactions to make system-level programming easier for users.",
);

#if (Content::InContentPage()) {
#}

Content::Add($conc, 2);

?>
