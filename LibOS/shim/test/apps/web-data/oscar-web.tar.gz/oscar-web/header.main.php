<?php 
# header.main.php
#
# Author: Chia-che Tsai
# Created: 09/09/2011
# Updated: 09/10/2011

if (!defined('IN_SERVER')) {
    exit('Access Denied');
}

include_once SERVER_ROOT . 'header.php';
?>
        <div class="wrapper navigation">
           <div class="univ" style="background-image: url(<? echo URL_ROOT ?>images/sbu-logo-small.gif)">
               <a href="http://www.stonybrook.edu/" target="_blank">
                    <span>Stony Brook University</span>
               </a>
            </div>
            <div class="dept" style="background-image: url(<? echo URL_ROOT ?>images/cs-logo-small.gif)">
                <a href="http://www.cs.stonybrook.edu/" target="_blank">
                    <span>Computer Science Department</span>
                </a>
            </div>
        </div>

        <div class="wrapper">
            <div class="header" style="background-image: url(<? echo URL_ROOT ?>images/banner.jpg)">
            <a href="<? echo URL_ROOT ?>index.php">
                <div class="title">
                    <span class="l1"><b>O</b>perating System <b>S</b>ecurity <b>C</b>oncurrency<br/></span>
                    <span class="l2">and <b>A</b>rchitecture <b>R</b>esearch Lab</span>
                </div>
            </a>
            </div>
        </div>
    </div>

    <div class="content_wrapper">
        <div class="wrapper">

            <div class="gears">
                <div class="gear1" style="background-image: url(<? echo URL_ROOT ?>images/gear1.png)">
                    <p><a href="<? echo URL_ROOT . PAGE_FILENAME ?>"><? echo PAGE_NAME ?></a></p>
                </div>

<?php
include_once SERVER_ROOT . 'menu.php';

$class = "gear2";
foreach ($primary_menu as $filename => $name) {
    if ($filename == PAGE_FILENAME) continue;
?>
                <div class="<? echo $class ?>" style="background-image: url(<? echo URL_ROOT ?>images/gear2.png)">
                    <p><a href="<? echo URL_ROOT . $filename ?>"><? echo $name ?></a></p>
                </div>
<?php
    if ($class == "gear2") $class = "gear3";
    else $class = "gear2";
}
?>
            </div>

            <div class="content">
<?php
foreach (Content::Includable($_GET['page']) as $script) {
    Content::NextContentPage($script);
    echo "<!-- include_once $script -->";
    include_once $script;
}

if (defined('CONTENT_PAGE')) { ?>
    <div class="content_page">
<? }

if (!defined('CONTENT_PAGE')) {
    Content::Sort(defined('REVERSE_SORT') && REVERSED_SORT);
}
?>
