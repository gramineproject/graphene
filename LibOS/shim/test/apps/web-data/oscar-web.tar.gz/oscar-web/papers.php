<?php
# papers.php
#
# Author: Chia-che Tsai
# Created: 08/03/2012
# Updated: 08/03/2012


define('PAGE_TITLE', 'Papers');

define('SERVER_ROOT', dirname($_SERVER['SCRIPT_FILENAME']) . '/');
define('IN_SERVER', true);

include_once SERVER_ROOT . 'attribute.php';
include_once SERVER_ROOT . 'common.php';

define('PAGE_NAME', 'Papers');
define('PAGE_FILENAME', 'papers.php');
define('CONTENT_TYPE', 'papers');
define('REVERSE_SORT', true);

include_once SERVER_ROOT . 'common.main.php';
include_once SERVER_ROOT . 'header.main.php';
?>

    <h1> Paper Published
        <? if (defined('CONTENT_PAGE')) {
               $items = Content::Items();
               echo '> ' . $items[0]['title'];
           } ?>
    </h1>

<div class="content_list">
<? 
if (count(Content::Items()) <= 0) {
?>
    <h6> </h6>
<?
} else {
    foreach (Content::Items() as $item) {
?>
    <div class="papers">
        <? if ($item['title']) { ?>
            <div class="title"><? echo $item['title'] ?></div> 
        <? } ?>

        <? if ($item['publish']) { ?>
            <div class="publish"> published on
            <? if ($item['publish_link']) { ?>
                <a href="<? echo $item['publish_link'] ?>">
                <? echo $item['publish'] ?>
                </a>
            <? } else { ?>
                <? echo $item['publish'] ?>
            <? } ?>
            </div>
        <? } ?>

        <? if ($item['biblio']) { ?>
            <div class="biblio"><? echo $item['biblio'] ?></div>
        <? } ?>

        <? if ($item['format']) { ?>
            <div class="format">
            <? foreach ($item['format'] as $type => $link) { ?>
                <a href="<? echo $link ?>">[<? echo $type ?>]</a>
            <? } ?>
            </div>
        <? } ?>


        <? if (!defined('CONTENT_PAGE') && $item['page']) { ?>
            <a class="readmore" href="<? echo URL_ROOT . PAGE_FILENAME . '?page=' . $item['page']?>">
                Read More
            </a>
        <? } ?>
    </div>
<?
    }
}
?>
</div>

<?php
include_once SERVER_ROOT . 'footer.main.php';
?>
