<?php
# index.php
#
# Author: Chia-che Tsai
# Created: 09/08/2011
# Updated: 09/12/2011

if (!defined('IN_PREVIEW')) {
    define('IN_PREVIEW', true);
    define('PREVIEW_PATH', $_SERVER['SCRIPT_FILENAME']);
    define('SERVER_REAL_ROOT', dirname($_SERVER['SCRIPT_FILENAME']) . '/');

    $ref = $_GET['ref'];
    $path = $_GET['path'];

    if (!$ref || !$path) {
        exit('\'ref\' and \'path\' has to be given as argument! <br />');
    }

    $script_required = true;

    define('IN_SERVER', true);
    define('URL_ROOT', dirname('http://' . $_SERVER['HTTP_HOST'] .
        $_SERVER['SCRIPT_NAME']) . "/preview.php?ref=$ref&path=");

    $included_paths = array();

    function preview_server_root ($path) {
        return SERVER_REAL_ROOT . $path;
    }

    $opened_dirs = array();
    $recently_opened = false;

    function preview_opendir ($path) {
        global $ref;
        global $opened_dirs;
        global $recently_opened;

        if ($path[0] == '/') {
            if (strpos($path, SERVER_REAL_ROOT) === 0) {
                $path = substr($path, strlen(SERVER_REAL_ROOT));
            } else {
                $recently_opened = opendir($path);
                return $recently_opened;
            }
        }

        exec("git ls-tree --name-only $ref $path", $output, $retval);

        if ($retval != 0) {
            return false;
        }

        $files = array();

        foreach ($output as $out) {
            if (strpos($out, $path) === 0) {
                $file = substr($out, strlen($path));

                if ($file[0] == '/') {
                    $file = substr($file, 1);
                }

                array_push($files, $file);
            }
        }

        echo "\n<!-- opendir($path) = " . implode(' ', $files) . " -->\n\n";
        $opened_dirs[$path] = $files;

        $recently_opened = $path;
        return $recently_opened;
    }

    function preview_readdir ($dir) {
        global $opened_dirs;
        global $recently_opened;

        if (!$dir) {
            $dir = $recently_opened;
        }

        $type = gettype($dir);

        if ($type == "resource") {
            return readdir($dir);
        }

        if ($type == "string") {
            $val = array_shift($opened_dirs[$dir]);

            if ($val != NULL) {
                echo "\n<!-- readdir($dir) = $val -->\n\n";
                return $val;
            }
        }

        return false;
    }

    function preview_closedir (&$dir) {
        global $opened_dirs;
        global $recently_opened;

        if (!$dir) {
            $dir = $recently_opened;
        }

        $type = gettype($dir);

        if ($type == "resource") {
            return closedir($dir);
        }

        if ($type == "string") {
            unset($opened_dirs[$dir]);
        }

        return true;
    }

    define('HAS_SERVER_ROOT', true);
    define('HAS_', false);

    function preview_include ($has_server_root, $file, $require = false, $once = false) {
        global $path, $script_required;

        if (!$has_server_root) {
            if ($file[0] == '/') {
                if (strpos($file, SERVER_REAL_ROOT) === 0) {
                    $file = substr($file, strlen(SERVER_REAL_ROOT));
                } else {
                    if ($once) {
                        $included_files = get_included_files();
                        if (array_search($file, $included_files)) {
                            return '';
                        }
                    }
                    return file;
                }
            }
        }

        if ($once) {
            if (array_search($file, $included_paths)) {
                return '';
            } else {
                array_push($included_paths, $file);
            }
        }

        $script_required = $require;
        $path = $file;

        echo "\n<!-- $path included -->\n\n";
        return PREVIEW_PATH;
    }

    function preview_include_once ($has_server_root, $path) {
        return preview_include($has_server_root, $path, false, true);
    }

    function preview_require ($has_server_root, $path) {
        return preview_include($has_server_root, $path, true, false);
    }

    function preview_require_once ($has_server_root, $path) {
        return preview_include($has_server_root, $path, true, true);
    }
}

if (!$path) {
    exit();
}

$pathinfo = pathinfo($path);

if ($pathinfo
    && $pathinfo['extension'] != 'php'
    && $pathinfo['extension'] != 'php5') {
    passthru("git show $ref:$path");
    exit();
}

exec("git show $ref:$path", $preview, $retval);

if ($script_required && $retval != 0) {
    exit("'$path' does not exist in refspec '$ref'! <br />");
}

$preview = implode("\n", $preview);

$pattern = '/\<\?(?:php)?.*\?\>/Uims';

preg_match_all($pattern, $preview, $matches, PREG_OFFSET_CAPTURE);

$size = strlen($preview);
$cnt = 0;
$run = '';

foreach ($matches[0] as $match) {
    $script = $match[0];
    $offset = $match[1];

    if ($offset > $cnt) {
        $run .= ";\n echo <<<EOF\n" .
                substr($preview, $cnt, $offset - $cnt) . "\nEOF;\n";
    }

    $cnt = $offset + strlen($script);

    $script = preg_replace ('/^\<\?(?:php)?/im', '', $script);
    $script = preg_replace ('/\?\>$/im', '', $script);

    $script = preg_replace ('/((?:^|;)\s*)(include|require)(_once)?\s*[\s(]\s*' .
                            '(?:\s*(SERVER_ROOT)\s*.\s*)?([^;]*)\s*\)?\s*;/ism',
                            '$1include preview_$2$3(HAS_$4, $5);', $script);
    $script = preg_replace ('/SERVER_ROOT\s*\.\s*(\((?:(?:[^()]+)|(?1))*\))?([^();]*)/ism',
                            'preview_server_root($1$2)', $script);
    $script = preg_replace ('/define\s*\(\s*\'(?:SERVER_ROOT|IN_SERVER|URL_ROOT)\'[^;]*;/ism',
                            '', $script);
    $script = preg_replace ('/(opendir|readdir|closedir)\s*\(/ism',
                            'preview_$1(', $script);

    $run .= $script;
}

if ($cnt < $size) {
    $run .= ";\n echo <<<EOF\n" .
            substr($preview, $cnt, $size - $cnt) . "\nEOF;\n";
}

if ($_GET['raw'] == '1') {
    echo $run;
} else {
    ob_start();
    eval($run);
    $result = ob_get_clean();

    $result = preg_replace ('/("[^"]+\.php\?[^"]*)\?([^"]+")/ism',
                            '$1&$2', $result);

    echo $result;
}
