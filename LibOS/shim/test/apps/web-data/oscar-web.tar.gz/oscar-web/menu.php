<?php
# menu.php
#
# Author: Chia-che Tsai
# Created: 09/10/2011
# Updated: 09/10/2011

if (!defined('IN_SERVER')) {
    exit('Access Denied');
}

$primary_menu = array(
    "news.php"        => "News",
    "people.php"      => "People",
    "projects.php"    => "Projects",
    "papers.php"      => "Papers",
    "sponsors.php"     => "Sponsors"
);
?>
