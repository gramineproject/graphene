<?php

## Fill in the information
#

$naveen = array(
    "name"       => "Naveen Kumar Kalaskar",
    "title"      => "Masters Student, Fall 2011",
    "office"     => "2203, OSCAR LAB, Computer Science",
    "email"      => "nkalaskar@cs.stonybrook.edu, naveen.kalaskar@gmail.com",
    "website"    => "",
    "phone"      => "571 423 9479",
    "fax"        => "",
    "photo"      => "people/photos/naveen.jpg",
);


if (Content::InContentPage()) {
?>

<h3>History</h3>

<table style="border-width: 0">
<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em"><b>Fall '11 - Now</b><br/><i>Graduate Student</i></td>
<td style="border-width: 0; padding: 0.3em"><b>Stony Brook University</b><br/>Computer Science Department<br/><a href="http://www.cs.stonybrook.edu" target="_blank">website</a></td>                              
</tr>
<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em">December '07 - July '11<br/><i>Employment</i></td>
<td style="border-width: 0; padding: 0.3em"><b>IBM</b><br/>Bangalore, India<br/><a href="http://www.in.ibm.com" target="_blank">website</a></td>                              
</tr>
<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em">September '03 - May '07<br/><i>Under Graduate</i></td>
<td style="border-width: 0; padding: 0.3em"><b>Jawahar Lal Nehru Technological University, Hyderabad</b><br/>Bachelor of Technology, Computer Science and Engineering<br/><a href="http://www.jntu.ac.in/new/" target="_blank">website</a></td>                              
</tr>

</tr></tr></table>

<?
}

Content::Add($naveen, 'kalaskar');

?>
