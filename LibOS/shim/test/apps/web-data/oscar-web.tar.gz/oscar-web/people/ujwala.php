<?php

$ujwala = array(
    "name"       => "Ujwala Tulshigiri",
    "title"      => "Graduate Student, Computer Science, Stony Brook University",
    "office"     => "2203 Computer Science",
    "email"      => "utulshigiri@cs.stonybrook.edu",
    "website"    => "",
    "phone"      => "",
    "fax"        => "",
    "photo"      => "people/photos/ujwala.jpg",
);

if (Content::InContentPage()) {
?>

<h3>History</h3>

<table style="border-width: 0">

<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em"><b>Summer '12 </b><br/><i>(Research Intern)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>EMC/Data Domain</b><br/>Princeton, New Jersey<br/><a href="http://www.emc.com" target="_blank">website</a></td>

<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em"><b>Fall '11 - Now</b><br/><i>(Graduate)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>Stony Brook University</b><br/>MS, Computer Science<br/><a href="http://www.cs.stonybrook.edu" target="_blank">website</a></td>                              

</tr>
<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em"><b>July '09 - July '11</b><br/><i>(System Software Developer)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>IBM India Software Lab</b><br/>India<br/><a href="http://www.ibm.com" target="_blank">website</a></td>                              
</tr>
<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em"><b>Summer '08</b><br/><i>(Intern)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>IBM India Software Lab</b><br/>India<a href="http://www.ibm.com" target="_blank">website</a></td>                   

</tr>
<tr style="border-width: 0">
<td style="border-width: 0; padding: 0.3em">July '05 - May '09<br/><i>(Undergraduate)</i></td>
<td style="border-width: 0; padding: 0.3em"><b>College of Engineering, Pune, India</b><br/>Bachelor of Technology, Computer Science<br/><a href="http://www.coep.org.in" target="_blank">website</a></td>                              

</tr></tr></table>

<h3>Publications</h3>

<ul>

<li style="margin-bottom: 2em"><b>Immutability and appendOnly features in GPFS 3.4v on AIX</b> [<a href="http://www.ibm.com/developerworks/aix/library/au-gpfs/index1.html">URL</a></a>]<br/>
Sandeep Patil, <b>Ujwala Tulshigiri</b><br/>
IBM developerWorks, April 2012</li>

<li style="margin-bottom: 2em"><b>Information Lifecycle Management for AIX data using IBM SONAS</b> [<a href="http://www.ibm.com/developerworks/aix/library/au-lifecycle_sonas/index.html">URL</a></a>]</b><br/>
<b>Ujwala Tulshigiri</b>, and Bhushan Jain<br/>
IBM developerWorks, August 2011<br/></li>

</ul>

<?
}

Content::Add($ujwala, 'tulshigiri');

?>
