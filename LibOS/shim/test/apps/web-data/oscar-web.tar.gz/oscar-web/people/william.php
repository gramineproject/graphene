<?php

$william = array(
    "name"       => "William Jannen",
    "title"      => "Doctoral Student, Computer Science, Stony Brook University",
    "office"     => "2203 Computer Science",
    "email"      => "wjannen@cs.stonybrook.edu",
    "website"    => "http://www.cs.stonybrook.edu/~wjannen/",
    "phone"      => "",
    "fax"        => "",
    "photo"      => "people/photos/WilliamJannen.jpg",
);

#if (Content::InContentPage()) {
#}

Content::Add($william, 'jannen');

?>
