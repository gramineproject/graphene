<?php

$gurpreet = array(
    "name"       => "Gurpreet Chadha",
    "title"      => "Masters Student, Computer Science, Stony Brook University",
    "office"     => "2203 Computer Science",
    "email"      => "gchadha@cs.cs.stonybrook.edu",
    "website"    => "",
    "phone"      => "",
    "fax"        => "",
    "photo"      => "people/photos/gurpreet.jpg",
    "alumnus"    => True,
);

#if (Content::InContentPage()) {
#}

Content::Add($gurpreet, 'chadha');

?>
