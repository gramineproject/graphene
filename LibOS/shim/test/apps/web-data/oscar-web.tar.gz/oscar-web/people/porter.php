<?php

$porter = array(
    "name"       => "Donald Porter",
    "title"      => "Assistant Professor, Computer Science, Stony Brook University",
    "office"     => "1434 Computer Science",
    "email"      => "porter@cs.stonybrook.edu",
    "website"    => "http://www.cs.sunysb.edu/~porter/",
    "phone"      => "",
    "fax"        => "",
    "photo"      => "people/photos/porter.png",
);

#if (Content::InContentPage()) {
#
#}

Content::Add($porter);
?>
