<?php 
# header.php
#
# Author: Chia-che Tsai
# Created: 09/08/2011
# Updated: 09/12/2011

if (!defined('IN_SERVER')) {
    exit('Access Denied');
}
?>

<html>

<head>
    <title><? echo PAGE_TITLE ?> | <? echo SERVER_NAME ?></title>

    <link rel="StyleSheet" href="<? echo URL_ROOT ?>style.css" type="text/css">
    <link rel='Shortcut Icon' href="<? echo URL_ROOT ?>images/oscar-favicon.png" type="image/png">

</head>

<body>
    <?php include_once("googleanalytics.php") ?>
    <div class="wrapper">
