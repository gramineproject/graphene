<?php

## Fill in the information
#

$nsf_career = array(
    "project"     => "Research Support Grant",
    "name"        => "Stony Brook University, Office of the Vice President for Research",
    "website"     => "http://www.stonybrook.edu",
    "logo"        => "sponsors/logo/sbu.jpg",
    "logo_width"  => 127,
    "logo_height" => 90,
    "description" => "",
);

## The following content will be shown in a individual page.
#
# if (Content::InContentPage()) {
# }

## Add it to the content.
#
Content::Add($nsf_career, 1);

?>
