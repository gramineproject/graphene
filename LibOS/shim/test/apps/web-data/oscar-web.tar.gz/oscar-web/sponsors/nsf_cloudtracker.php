<?php

## Fill in the information
#

$nsf_cloudtracker = array(
    "project"     => "Award CNS-1161541",
    "name"        => "National Science Foundation (NSF)",
    "website"     => "http://www.nsf.gov",
    "logo"        => "sponsors/logo/nsf.jpg",
    "logo_width"  => 186,
    "logo_height" => 177,
    "description" => "",
);

## The following content will be shown in a individual page.
#
# if (Content::InContentPage()) {
# }

## Add it to the content.
#
Content::Add($nsf_cloudtracker, 0);

?>
