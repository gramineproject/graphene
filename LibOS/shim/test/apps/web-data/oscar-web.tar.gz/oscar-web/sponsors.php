<?php
# news.php
#
# Author: Chia-che Tsai
# Created: 09/12/2011
# Updated: 09/12/2011


define('PAGE_TITLE', 'News');

define('SERVER_ROOT', dirname($_SERVER['SCRIPT_FILENAME']) . '/');
define('IN_SERVER', true);

include_once SERVER_ROOT . 'attribute.php';
include_once SERVER_ROOT . 'common.php';

define('PAGE_NAME', 'Sponsors');
define('PAGE_FILENAME', 'sponsors.php');
define('CONTENT_TYPE', 'sponsors');

include_once SERVER_ROOT . 'common.main.php';
include_once SERVER_ROOT . 'header.main.php';
?>

    <h3> Sponsors
        <? if (defined('CONTENT_PAGE')) {
               $items = Content::Items();
               echo '> ' . $items[0]['title'];
           } ?>
    </h3>

<? if (!defined('CONTENT_PAGE')) { ?>
    <h6>Our work will not be done without the generous support of our
    sponsors. It is our pleasure to work with our partners. We gratefully
    acknowkedge our sponsors as follows:</h6>
<? } ?>

<?
if (count(Content::Items()) > 0) {
    $items = Content::Items();

    $max_width = 640;
    $grid_width = 20;
    $line_num = -1;
    $line_height = array();
    $line_width = array();
    $total_height = 0;
    $total_width = 0;

    $displayed_logos = array();

    foreach ($items as &$item) {
        if ($item['logo'] && $item['logo_width'] && $item['logo_height']) {
            if (array_search($item['logo'], $displayed_logos) !== false) {
                continue;
            }
            array_push($displayed_logos, $item['logo']);

            if ($line_num == -1 ||
                $line_width[$line_num] + $item['logo_width'] + $grid_width > $max_width) {
                array_push($line_height, 0);
                array_push($line_width, $grid_width);
                $line_num++;
                if ($line_num) {
                    $total_height += $line_height[$line_num - 1];
                }
            }
            $item['logo_line'] = $line_num;
            $item['logo_x'] = $line_width[$line_num];
            $item['logo_y'] = $total_height;
            $line_width[$line_num] += $item['logo_width'] + $grid_width;
            if ($line_height[$line_num] < $item['logo_height'] + $grid_width) {
                $line_height[$line_num] = $item['logo_height'] + $grid_width;
            }
            if ($total_width < $line_width[$line_num]) {
                $total_width = $line_width[$line_num];
            }
        }
    }
    if ($line_num != -1) {
        $total_height += $line_height[$line_num];
    }
    foreach ($items as &$item) {
        if (is_int($item['logo_line'])) {
            $line = $item['logo_line'];
            $item['logo_x'] += ($total_width - $line_width[$line]) / 2;
            $item['logo_y'] += ($line_height[$line] - $item['logo_height']) / 2;
        }
    }
?>
<div class="imagecloud"
 style="width:<? echo $total_width ?> !important;
        height:<? echo $total_height ?> !important;">
<?
    foreach ($items as &$item) {
        if (is_int($item['logo_line'])) {
        ?>
            <img src="<? echo URL_ROOT . $item['logo'] ?>"
             style="position: absolute;
                    left:<? echo $item['logo_x'] ?>;
                    top:<? echo $item['logo_y'] ?>;
                    width:<? echo $item['logo_width'] ?>;
                    height:<? echo $item['logo_height'] ?>;" />
        <?
        }
    }
?>
</div>
<div class="content_list">
<?
    foreach ($items as &$item) {
?>
    <div class="sponsors">
        <? if ($item['logo']) { ?>
            <div class="logo"><img src="<? echo URL_ROOT . $item['logo'] ?>"></div>
        <? } ?>

        <? if ($item['name'] || $item['project']) { ?>
            <div class="organization">
            <? if ($item['name']) { ?>
                <div class="name"><? echo $item['name'] ?></div>
            <? } ?>

            <? if ($item['project']) { ?>
                <div class="project"><? echo $item['project'] ?></div>
            <? } ?>

            <? if ($item['website']) { ?>
                <div class="website">
                    <a href="<? echo $item['website'] ?>">website</a>
                </div>
            <? } ?>
            </div>
        <? } ?>

        <? if ($item['discription']) { ?>
            <div class="desc"><? echo $item['description'] ?></div>
        <? } ?>

        <? if (!defined('CONTENT_PAGE') && $item['page']) { ?>
            <a class="readmore" href="<? echo URL_ROOT . PAGE_FILENAME . '?page=' . $item['page']?>">
                Read More
            </a>
        <? } ?>
    </div>
<?
    }
?>
</div>
<?
}

include_once SERVER_ROOT . 'footer.main.php';
?>
