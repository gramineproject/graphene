<?php 
# footer.main.php
#
# Author: Chia-che Tsai
# Created: 09/09/2011
# Updated: 09/09/2011

if (!defined('IN_SERVER')) {
    exit('Access Denied');
}

if (defined('CONTENT_PAGE')) {
    define('IN_CONTENT_PAGE', TRUE);
    include CONTENT_PAGE;
}

if (defined('CONTENT_PAGE')) { ?>
    </div>
<? }
?>
            </div>
        </div>
    </div>

    <div class="wrapper">
<?php
include_once SERVER_ROOT . 'footer.php';
?>
